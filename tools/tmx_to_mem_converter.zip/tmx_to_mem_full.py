from pytmx import TiledMap
from PIL import Image
import sys
import os

def extract_font_mem(tileset_path, tile_width, tile_height, output_file):
    img = Image.open(tileset_path).convert("1")  # modo 1bit
    img_w, img_h = img.size
    tiles_x = img_w // tile_width
    tiles_y = img_h // tile_height

    print(f"[INFO] Generando fuente desde: {tileset_path}")
    print(f"[INFO] Tiles en tileset: {tiles_x}x{tiles_y}")

    with open(output_file, "w") as f:
        for ty in range(tiles_y):
            for tx in range(tiles_x):
                for row in range(tile_height):
                    byte = 0
                    for col in range(tile_width):
                        pixel = img.getpixel((tx * tile_width + col, ty * tile_height + row))
                        bit = 1 if pixel == 0 else 0  # 0 = negro = activo
                        byte |= (bit << (7 - col))
                    f.write(f"{byte:02X}\n")

    print(f"[OK] Fuente exportada a: {output_file}")

def extract_screen_mem(tmx_path, output_file, layer_name=None):
    tmx = TiledMap(tmx_path)
    layer = None
    if layer_name:
        for l in tmx.layers:
            if l.name == layer_name:
                layer = l
                break
    else:
        layer = next((l for l in tmx.layers if hasattr(l, 'data')), None)

    if not layer:
        raise ValueError("No se encontró una capa válida con tiles")

    width, height = layer.width, layer.height
    print(f"[INFO] Generando RAM de vídeo desde: {tmx_path} ({width}x{height})")

    with open(output_file, "w") as f:
        for y in range(height):
            for x in range(width):
                gid = layer.data[y][x]
                index = gid - 1  # GID 1 = tile 0
                if index < 0 or index > 255:
                    index = 0
                f.write(f"{index:02X}\n")

    print(f"[OK] RAM de pantalla exportada a: {output_file}")

# --- Uso ---
if __name__ == "__main__":
    if len(sys.argv) < 4:
        print("Uso: python tmx_to_mem_full.py mapa.tmx tileset.png nombre_capa")
        sys.exit(1)

    tmx_file = sys.argv[1]
    tileset_file = sys.argv[2]
    capa = sys.argv[3]

    extract_font_mem(tileset_file, 8, 8, "font8x8.mem")
    extract_screen_mem(tmx_file, "screen.mem", capa)
